<img align="right" src='https://github.com/saudpw/saudpw/blob/master/source/gifs/hey.gif' width="150" height="150">

### Hi there, I'm saud <img src="https://github.com/saudpw/saudpw/blob/master/Assets/Hi.gif" width="22px">

[![Web Badge](https://img.shields.io/badge/-niveshb.com-lighgreen?style=flat-square&logo=webmoney&logoColor=white&link=https://niveshb.com)](https://niveshb.com)
[![Youtube](https://img.shields.io/youtube/views/udY540zICDY?style=social)](https://www.youtube.com/watch?v=udY540zICDY&t=12s)

<img align="right" src='https://github.com/niveshbirangal/niveshbirangal/blob/master/source/gifs/song.gif' width="150" height="150">

### Spotify Playing 🎧
[<img src="https://spotifynowplaying.vercel.app/api/spotify-playing" alt="Nivesh Birangal Spotify Playing" width="350" />](https://open.spotify.com/user/niveshbirangal)

### Connect with me:

[<img align="left" alt="niveshb.com" width="32px" src="https://raw.githubusercontent.com/niveshbirangal/saudpw/master/source/website.svg"/>][website]
[<img align="left" alt="niveshbirangal | LinkedIn" width="32px" src="https://raw.githubusercontent.com/saudpw/saudpw/master/source/linkedin.svg"/>][linkedin]
[<img align="left" alt="niveshbirangal | Instagram" width="32px" src="https://raw.githubusercontent.com/saudpw/saudpw/master/source/instagram.svg"/>][instagram]
[<img align="left" alt="niveshbirangal | YouTube" width="32px" src="https://raw.githubusercontent.com/saudpw/saudpw/master/source/youtube.svg"/>][youtube]

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img align="center" src='https://github.com/saudpw/saudpw/blob/master/source/gifs/head.gif' width="300">

[website]: https://saud.pw
[youtube]: 
[instagram]: https://instagram.com/saudpw
[linkedin]: https://linkedin.com/in/saudpw
